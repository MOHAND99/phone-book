#ifndef add_h
#define add_h
#include "declare.h"
void add(telephonebk arr_contacts[],int);
#endif
