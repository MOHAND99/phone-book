#ifndef contentprint_h
#define contentprint_h
void contentPrint(telephonebk arr_contacts[],int);
#endif
