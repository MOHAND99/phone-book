#ifndef delete_h
#define delete_h
void deleteContent(telephonebk arr_contacts[],int,int);
#endif
