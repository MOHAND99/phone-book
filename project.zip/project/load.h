#ifndef load_h
#define load_h
#include "declare.h"
void load(int);
void getContent();
int getCount(int);
#endif
