#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "load.h"

int main()
{
    int count =0;
    load(count);
    return 0;
}

