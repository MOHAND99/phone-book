#ifndef modify_h
#define modify_h
#include "declare.h"
void modify(telephonebk arr_contacts[],int,int);
#endif
