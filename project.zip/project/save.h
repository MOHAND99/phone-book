#ifndef save_h
#define save_h
void saveToFile(telephonebk arr_contacts[],int,int);
#endif
