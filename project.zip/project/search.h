#ifndef search_h
#define search_h
void search(char,telephonebk arr_contents[],int,int);
void query(telephonebk arr_contacts[],int);
#endif
