#ifndef sortprint_h
#define sortprint_h
void sortByLastName(telephonebk arr_contacts[],int,int);
void sortByBirthDay(telephonebk arr_contacts[],int,int);
void pSort();
#endif
